import 'dart:io';

import 'package:covid_tracker/models/Country.dart';
import 'package:dio/dio.dart';

class SearchHelper{

   Dio dio;
    Future<List<Country>> searchLocation(String searchTerm) async{    
        //TODO: Call location service
        //Get locations according to search, add to list

        
        List<Country> countries = [];
     dio = Dio();
     String url = "https://restcountries.eu/rest/v2/name/$searchTerm";
        await dio.get(url).then((response){
            var responseBody = response.data;
            for (var country in responseBody) {

              Country myCountry = Country(name: country["name"].toString(), flagUrl: country["flag"].toString());
              countries.add(myCountry);
            }
            // var responseBody = response.data;
             print('Data Fetch success:::');
             print('Data:: $responseBody');
           
        }).catchError((e){
          print('Error Encountered Fecthcing from API.::: ${e.message}');
        });
        

        return countries;

    }  
}