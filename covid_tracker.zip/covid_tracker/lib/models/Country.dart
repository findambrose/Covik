class Country{
  String name;
  String flagUrl;
  String searchUrl;

  Country ({this.name, this.flagUrl, this.searchUrl});

}