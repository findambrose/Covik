import 'package:covid_tracker/controllers/Search.dart';
import 'package:covid_tracker/utils/SharedPrefUtil.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Map cStats = {};

  String worldStats;

  String countryStats;

  SharedPrefUtil _sharedPrefUtil = new SharedPrefUtil();

  @override
  Widget build(BuildContext context) {
    cStats =
        cStats.isNotEmpty ? cStats : ModalRoute.of(context).settings.arguments;
    worldStats = cStats['worldStat'];
    countryStats = cStats['countryStat'];
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Home'),
        actions: <Widget>[
          FlatButton.icon(
              label: Text('Search country'),
              icon: Icon(Icons.search),
              onPressed: () {
                showSearch(context: context, delegate: Search());
              })
        ],
      ),
      body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage('assets/bg.png'), fit: BoxFit.fill),
          ),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(11.0),
              child: Column(
                children: <Widget>[
                  //Cards To Display Stats, Country, Flag
                  RefreshIndicator(
                    onRefresh: () async {
                      await _sharedPrefUtil.getLocation();
                      var storedLocation = _sharedPrefUtil.storedUserLocation;

                      Navigator.pushNamed(context, '/loading', arguments: {
                        'flagUrl': storedLocation[0],
                        'name': storedLocation[1],
                        'searchUrl': storedLocation[2]
                      });
                      return null;
                    },
                    child: Row(
                      children: <Widget>[
                        //World count
                        Expanded(
                          child: Container(
                            padding: EdgeInsets.all(5),
                            height: MediaQuery.of(context).size.height * .15,
                            decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(10)),
                            child: Column(
                              children: <Widget>[
                                Container(
                                  child: Text('World Cases Today'),
                                  decoration: BoxDecoration(
                                    color: Colors.orangeAccent,
                                  ),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  worldStats,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                  ),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text('Recovered:' +
                                    ' ' +
                                    cStats['worldRecovered']),
                                SizedBox(
                                  height: 5,
                                ),
                                Text('Deaths:' + ' ' + cStats['worldDeaths']),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(width: 10),
                        //Countrywide stats
                        Expanded(
                          child: Container(
                            padding: EdgeInsets.all(5),
                            height: MediaQuery.of(context).size.height * .15,
                            decoration: BoxDecoration(
                                color: Colors.green,
                                borderRadius: BorderRadius.circular(10)),
                            child: Column(
                              children: <Widget>[
                                Container(
                                    decoration: BoxDecoration(
                                      color: Colors.orangeAccent,
                                    ),
                                    child: Text('Country Cases Today',
                                        textAlign: TextAlign.center)),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  countryStats,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                  ),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text('Recovered:' +
                                    ' ' +
                                    cStats['countryRecovered']),
                                SizedBox(
                                  height: 5,
                                ),
                                Text('Deaths:' + ' ' + cStats['countryDeaths']),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Column(
                    children: <Widget>[
                      Text(
                        'Symptoms',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 2),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        height: MediaQuery.of(context).size.height * .3,
                        width: MediaQuery.of(context).size.width,
                        margin: EdgeInsets.all(4),
                        padding: EdgeInsets.all(4),
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: <Widget>[
                            Container(
                              //Symptom 1
                              padding: EdgeInsets.all(5),
                              width: 50,

                              //decoration: BoxDecoration(color: Colors.white),

                              child: ListTile(
                                leading: SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: Icon(
                                      Icons.headset_mic,
                                      size: 10,
                                    )),
                                title: Text('First Symptom'),
                                subtitle: Text(
                                    'Lorem Ipsum has been the industry\'s '),
                              ),
                            ),
                            Container(
                              width: 50,
                              //Symptom 2
                              padding: EdgeInsets.all(5),
                              decoration:
                                  BoxDecoration(color: Colors.lightGreen),
                              child: Card(
                                elevation: 3,
                                color: Colors.black26,
                                child: ListTile(
                                  leading: Icon(
                                    Icons.headset_mic,
                                    size: 10,
                                  ),
                                  title: Text('Second Symptom'),
                                  subtitle: Text(
                                      'Lorem Ipsum has been the industry\'s '),
                                ),
                              ),
                            ),
                            Container(
                              width: 50,
                              //Symptom 3
                              padding: EdgeInsets.all(5),
                              decoration:
                                  BoxDecoration(color: Colors.lightGreen),
                              child: Card(
                                elevation: 3,
                                color: Colors.black26,
                                child: ListTile(
                                  leading: Icon(
                                    Icons.headset_mic,
                                    size: 10,
                                  ),
                                  title: Text('Third Symptom'),
                                  subtitle: Text(
                                      'Lorem Ipsum has been the industry\'s '),
                                ),
                              ),
                            ),
                            Container(
                              width: 50,
                              //Symptom 4
                              padding: EdgeInsets.all(5),
                              decoration:
                                  BoxDecoration(color: Colors.lightGreen),
                              child: Card(
                                elevation: 3,
                                color: Colors.black26,
                                child: ListTile(
                                  leading: Icon(
                                    Icons.headset_mic,
                                    size: 10,
                                  ),
                                  title: Text('Fourth Symptom'),
                                  subtitle: Text(
                                      'Lorem Ipsum has been the industry\'s '),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ), //Symptoms slideshow

                  //START OF MEASURES
                  SizedBox(
                    height: 3,
                  ),
                  Column(
                    children: <Widget>[
                      Text(
                        'Measures',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 2),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        height: MediaQuery.of(context).size.height * .3,
                        width: MediaQuery.of(context).size.width,
                        margin: EdgeInsets.all(5),
                        padding: EdgeInsets.all(5),
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration:
                                  BoxDecoration(color: Colors.lightGreen),
                              child: Card(
                                elevation: 3,
                                color: Colors.black26,
                                child: ListTile(
                                  leading: Icon(Icons.headset_mic),
                                  title: Text('Fisrt Measure'),
                                  subtitle: Text(
                                      'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration:
                                  BoxDecoration(color: Colors.lightGreen),
                              child: Card(
                                elevation: 3,
                                color: Colors.black26,
                                child: ListTile(
                                  leading: Icon(Icons.headset_mic),
                                  title: Text('Second Measure'),
                                  subtitle: Text(
                                      'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.all(5),
                              decoration:
                                  BoxDecoration(color: Colors.lightGreen),
                              child: Card(
                                elevation: 3,
                                color: Colors.black26,
                                child: ListTile(
                                  leading: Icon(Icons.headset_mic),
                                  title: Text('Third Measure'),
                                  subtitle: Text(
                                      'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
                                ),
                              ),
                            ),
                            Container(
                              //Symptom 1
                              padding: EdgeInsets.all(5),
                              decoration:
                                  BoxDecoration(color: Colors.lightGreen),
                              child: Card(
                                elevation: 3,
                                color: Colors.black26,
                                child: ListTile(
                                  leading: Icon(Icons.headset_mic),
                                  title: Text('Fourth Measure'),
                                  subtitle: Text(
                                      'Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.'),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ), //Measures slideshow
                ],
              ),
            ),
          )),
    );
  }
}
