import 'package:covid_tracker/controllers/Stats.dart';
import 'package:covid_tracker/models/Country.dart';
import 'package:covid_tracker/utils/SharedPrefUtil.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class Loading extends StatefulWidget {
  @override
  _LoadingState createState() => _LoadingState();
}

class _LoadingState extends State<Loading> {
  //bool _isLocationSaved = SharedPrefUtil.isLocationSaved;
  bool _isLocationSaved = false; //testing purpose

  Map _selectedCountry = {};
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, (){
      setUpStats();
    });
    
    
  }

  void setUpStats() async {
    SharedPrefUtil _sharedPrefUtil = SharedPrefUtil();
    _sharedPrefUtil.checkIfKeyExists();
    //Get stored location in sharedprefs

    if (_isLocationSaved) {
      await _sharedPrefUtil.getLocation();
      var storedLocation = _sharedPrefUtil.storedUserLocation;
      _selectedCountry = {
        'flagUrl': storedLocation[0],
        'name': storedLocation[1],
        'searchUrl': storedLocation[2]
      };
    }
    _selectedCountry = _selectedCountry.isNotEmpty
        ? _selectedCountry
        : ModalRoute.of(context).settings.arguments;
    Country country = Country(
        flagUrl: _selectedCountry['flagUrl'],
        name: _selectedCountry['name'],
        searchUrl: _selectedCountry['searchUrl']);
        // print(country.name);
        // return;

    Stats stats = Stats(location: country);
    await stats.getStatsByCountry();
    await stats.getWorldStats();
    Navigator.pushReplacementNamed(context, '/home', arguments: {
      'countryStat': stats.countryStat,
      'worldStat': stats.worldStat,
      'flagUrl': country.flagUrl,
      'name': country.name,
      'countryDeaths': stats.countryDeaths,
      'worldDeaths': stats.worldDeaths,
      'countryRecovered': stats.countryRecovery,
      'worldRecovered': stats.worldRecovery,

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          child: SpinKitRotatingCircle(
            color: Colors.green,
            size: 50.0,
          ),
        ),
      ),
    );
  }
}
