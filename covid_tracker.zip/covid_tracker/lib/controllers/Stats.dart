import 'package:covid_tracker/models/Country.dart';
import 'package:dio/dio.dart';
class Stats{

  //What i'll get
  String countryStat; 
  String worldStat; 
 
  //what i'll need
  Country location;

  String countryRecovery;

  String countryDeaths;

  String worldDeaths;

  String worldRecovery;
  Stats({this.location});
  
  //function 
  Future<void> getStatsByCountry() async{

   try {
    Dio dio = new Dio();
    Response response = await dio.get('https://disease.sh/v3/covid-19/countries/${location.name}');
    print(response.data['todayCases']);
    countryStat = response.data['todayCases'].toString();
    countryDeaths = response.data['todayDeaths'].toString();
    countryRecovery = response.data['todayRecovered'].toString();
    //country
   // print(response.data.body.toString().runtimeType);
   // print(response.data.body.runtimeType);
  } catch (e) {
    print(e);
    countryStat = 'Count not found, try reloading the page';
  } 
   
  }

   Future<void> getWorldStats() async{

    //1. code to get time from api and set it
    //2. 
  try {
    Dio dio = new Dio();
    Response response = await dio.get('https://disease.sh/v3/covid-19/all');
    print(response.data['todayCases']); 
   worldStat = response.data['todayCases'].toString();
    worldDeaths = response.data['todayDeaths'].toString();
    worldRecovery = response.data['todayRecovered'].toString();
  } catch (e) {
    print(e);
    worldStat = 'Stat not found, try reloading the page';

  }   
   
  }

}